# ETG-internship
Inventory management system
